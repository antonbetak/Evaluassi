"""
Evaluación de Exámenes - Módulo stub para migración gradual

Este archivo está preparado para la migración gradual desde exams.py
Por ahora, las rutas permanecen en el archivo original.

TODO: Migrar las siguientes funciones:
- evaluate_question()
- evaluate_exercise()
- evaluate_exam()
- save_exam_result()
- get_my_exam_results()
"""
# Las rutas permanecen en el módulo principal por ahora
