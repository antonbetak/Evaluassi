"""
Generación de PDFs - Módulo stub para migración gradual

Este archivo está preparado para la migración gradual desde exams.py
Por ahora, las rutas permanecen en el archivo original.

TODO: Migrar las siguientes funciones:
- generate_result_pdf()
- generate_certificate_pdf()
- upload_result_report()

NOTA: Este módulo será reemplazado por Azure Functions para procesamiento asíncrono
"""
# Las rutas permanecen en el módulo principal por ahora
