import{b as a}from"./index-DJa0AdgZ.js";const r={getDashboard:async()=>(await a.get("/users/me/dashboard")).data};export{r as d};
